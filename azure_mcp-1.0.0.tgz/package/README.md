# Azure DevOps MCP Server

A Model Context Protocol (MCP) server for integrating with Azure DevOps, enabling AI agents to create, update, and query work items and iterations.

## Features

- **Work Item Management**: Create, update, and query work items
- **Iteration Management**: List and create iterations
- **Flexible Querying**: Support for WIQL queries and filter-based queries
- **Team Support**: Work with specific teams or project defaults

## Installation

```bash
npm install
```

## Configuration

Create a `.env` file in the project root:

```env
# Azure DevOps Configuration
AZDO_ORG_URL=https://dev.azure.com/your-org
AZDO_PAT=your-personal-access-token

# Server Configuration (optional)
MCP_SERVER_NAME=azure-devops-server
MCP_SERVER_VERSION=1.0.0
```

### Getting a Personal Access Token

1. Go to [Azure DevOps](https://dev.azure.com)
2. Click on your profile → User Settings → Personal Access Tokens
3. Create a new token with the following scopes:
   - Work Items (Read & Write)
   - Project and Team (Read)

## Building

```bash
npm run build
```

## Running

```bash
npm start
```

## Available Tools

### create_work_item
Create a new work item in Azure DevOps.

**Parameters:**
- `project` (required): The project name or ID
- `type` (required): The type of work item (Task, Bug, Feature, User Story, Epic)
- `title` (required): The title of the work item
- `description` (optional): The description of the work item
- `assignedTo` (optional): The user to assign the work item to
- `tags` (optional): Tags to add to the work item

### update_work_item
Update an existing work item in Azure DevOps.

**Parameters:**
- `workItemId` (required): The ID of the work item to update
- `title` (optional): New title
- `description` (optional): New description
- `assignedTo` (optional): New assigned user
- `state` (optional): New state
- `tags` (optional): New tags

### list_work_items
List work items using WIQL query or filters.

**Parameters:**
- `project` (required): The project name or ID
- `wiql` (optional): Custom WIQL query (overrides other filters)
- `workItemType` (optional): Filter by work item type
- `assignedTo` (optional): Filter by assigned user
- `state` (optional): Filter by state

### list_iterations
List all iterations for a project or team.

**Parameters:**
- `project` (required): The project name or ID
- `team` (optional): The team name (defaults to project iterations)

### create_iteration
Create a new iteration in Azure DevOps.

**Parameters:**
- `project` (required): The project name or ID
- `name` (required): The name of the iteration
- `startDate` (required): The start date (ISO 8601 format: YYYY-MM-DD)
- `finishDate` (required): The finish date (ISO 8601 format: YYYY-MM-DD)
- `team` (optional): The team name

## Usage with Claude

Add the server to your Claude configuration:

```json
{
  "mcpServers": {
    "azure-devops": {
      "command": "node",
      "args": ["/path/to/azure_mcp/dist/index.js"],
      "env": {
        "AZDO_ORG_URL": "https://dev.azure.com/your-org",
        "AZDO_PAT": "your-pat"
      }
    }
  }
}
```

## Development

```bash
# Install dependencies
npm install

# Build the project
npm run build

# Run in development mode
npm run dev
```

## Project Structure

```
azure_mcp/
├── src/
│   ├── index.ts              # Main server entry point
│   ├── services/
│   │   └── azureDevOpsService.ts  # Azure DevOps API client
│   ├── tools/
│   │   ├── createWorkItem.ts
│   │   ├── updateWorkItem.ts
│   │   ├── listWorkItems.ts
│   │   ├── listIterations.ts
│   │   └── createIteration.ts
│   └── types/
│       └── index.ts          # TypeScript type definitions
├── dist/                     # Compiled JavaScript
├── .env                      # Environment variables
├── package.json
└── tsconfig.json
```

## License

MIT